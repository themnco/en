
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import StockChart from './components/StockChart';
import InfoPanel from './components/InfoPanel';
import { generateMockStockData } from './services/mockStockService';
import { getCompanyInfo } from './services/geminiService';
import { ChartDataPoint, CompanyInfo } from './types';

const App: React.FC = () => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('GOOGL');
  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStockData = useCallback(async (symbol: string) => {
    setIsLoading(true);
    setError(null);
    try {
      // In a real app, you'd fetch chart data from an API.
      // Here we use mock data generator.
      const mockChartDataPromise = Promise.resolve(generateMockStockData(symbol));
      const companyInfoPromise = getCompanyInfo(symbol);

      const [newChartData, newCompanyInfo] = await Promise.all([
        mockChartDataPromise,
        companyInfoPromise,
      ]);

      setChartData(newChartData);
      setCompanyInfo(newCompanyInfo);
      setSelectedSymbol(symbol);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to fetch data for ${symbol}. ${errorMessage}`);
      setChartData([]);
      setCompanyInfo(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStockData(selectedSymbol);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only on initial mount with the default symbol

  const handleSearch = (symbol: string) => {
    if (symbol.toUpperCase() !== selectedSymbol.toUpperCase()) {
        fetchStockData(symbol.toUpperCase());
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-6 space-y-6">
        <div className="p-6 bg-gray-800/50 rounded-lg shadow-xl">
            <SearchBar onSearch={handleSearch} isLoading={isLoading} initialSymbol={selectedSymbol} />
        </div>

        {error && (
            <div className="p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg text-center">
                <p><strong>Error:</strong> {error}</p>
            </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
                <StockChart data={chartData} symbol={selectedSymbol} />
            </div>
            <div className="lg:col-span-1">
                <InfoPanel info={companyInfo} isLoading={isLoading} symbol={selectedSymbol} />
            </div>
        </div>
      </main>
      <footer className="text-center p-4 text-gray-500 text-sm">
        <p>Data is for demonstration purposes only. Powered by Gemini.</p>
      </footer>
    </div>
  );
};

export default App;
