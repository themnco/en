
import React from 'react';
import { CompanyInfo } from '../types';
import LoadingSpinner from './LoadingSpinner';

// This is a helper component defined outside InfoPanel to avoid re-creation on re-renders.
const FormattedSummary: React.FC<{ summary: string }> = ({ summary }) => {
    // A simple parser to render basic markdown elements as styled spans/divs.
    // This avoids dangerouslySetInnerHTML.
    const lines = summary.split('\n');
    return (
        <div>
            {lines.map((line, index) => {
                if (line.trim() === '') return <div key={index} className="h-4" />;

                if (line.startsWith('### ')) {
                    return <h3 key={index} className="text-xl font-semibold text-gray-100 mt-4 mb-2">{line.substring(4)}</h3>;
                }
                if (line.startsWith('## ')) {
                    return <h2 key={index} className="text-2xl font-bold text-white mt-5 mb-3">{line.substring(3)}</h2>;
                }
                if (line.startsWith('# ')) {
                    return <h1 key={index} className="text-3xl font-bold text-white mt-6 mb-4">{line.substring(2)}</h1>;
                }
                if (line.startsWith('- ') || line.startsWith('* ')) {
                    return <li key={index} className="ml-5 list-disc list-item marker:text-blue-400">{line.substring(2)}</li>;
                }
                
                // Replace **bold** with <strong>
                const parts = line.split(/(\*\*.*?\*\*)/g);

                return (
                    <p key={index} className="my-2 text-gray-300">
                        {parts.map((part, i) => {
                            if (part.startsWith('**') && part.endsWith('**')) {
                                return <strong key={i} className="text-gray-100">{part.slice(2, -2)}</strong>;
                            }
                            return part;
                        })}
                    </p>
                );
            })}
        </div>
    );
};

// FIX: Define the props interface for the InfoPanel component.
interface InfoPanelProps {
  info: CompanyInfo | null;
  isLoading: boolean;
  symbol: string;
}

const InfoPanel: React.FC<InfoPanelProps> = ({ info, isLoading, symbol }) => {
  return (
    <div className="p-4 bg-gray-800 rounded-lg shadow-lg h-full flex flex-col min-h-[400px] lg:min-h-0">
      <h2 className="text-2xl font-bold text-white mb-4 flex-shrink-0">AI Analysis for {symbol}</h2>
      <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
        {isLoading && <LoadingSpinner />}
        {!isLoading && info && (
          <div>
            <FormattedSummary summary={info.summary} />
            
            {info.sources && info.sources.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold text-gray-200 border-t border-gray-700 pt-4">Sources</h3>
                <ul className="mt-2 space-y-2">
                  {info.sources.map((source, index) => (
                    <li key={index} className="text-blue-400 hover:text-blue-300 truncate">
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" title={source.web.title} className="block truncate">
                        {source.web.title || source.web.uri}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
        {!isLoading && !info && (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-400">Analysis will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InfoPanel;