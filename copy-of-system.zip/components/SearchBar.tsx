
import React, { useState } from 'react';

interface SearchBarProps {
  onSearch: (symbol: string) => void;
  isLoading: boolean;
  initialSymbol?: string;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch, isLoading, initialSymbol = '' }) => {
  const [symbol, setSymbol] = useState(initialSymbol);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (symbol.trim()) {
      onSearch(symbol.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 items-center w-full max-w-lg mx-auto">
      <input
        type="text"
        value={symbol}
        onChange={(e) => setSymbol(e.target.value)}
        placeholder="Enter stock symbol (e.g., GOOGL, MSFT)"
        className="flex-grow bg-gray-700 border border-gray-600 text-gray-200 text-lg rounded-md focus:ring-blue-500 focus:border-blue-500 block w-full p-3 transition"
        disabled={isLoading}
      />
      <button
        type="submit"
        disabled={isLoading || !symbol.trim()}
        className="text-white bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-lg px-6 py-3 text-center transition-colors"
      >
        {isLoading ? '...' : 'Search'}
      </button>
    </form>
  );
};

export default SearchBar;
