
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartDataPoint } from '../types';

interface StockChartProps {
  data: ChartDataPoint[];
  symbol: string;
}

const StockChart: React.FC<StockChartProps> = ({ data, symbol }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full bg-gray-800 rounded-lg min-h-[400px] lg:min-h-0">
        <p className="text-gray-400">Search for a symbol to display its chart.</p>
      </div>
    );
  }
  
  const lastPrice = data[data.length - 1].price;
  const firstPrice = data[0].price;
  const change = lastPrice - firstPrice;
  const changePercent = (change / firstPrice) * 100;
  const isPositive = change >= 0;

  return (
    <div className="p-4 bg-gray-800 rounded-lg shadow-lg h-full flex flex-col">
      <div className="mb-4">
        <h2 className="text-3xl font-bold text-white">{symbol}</h2>
        <div className="flex items-baseline gap-2">
            <p className="text-2xl font-semibold text-white">${lastPrice.toFixed(2)}</p>
            <p className={`text-lg font-medium ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {isPositive ? '+' : ''}{change.toFixed(2)} ({changePercent.toFixed(2)}%)
            </p>
        </div>
      </div>
      <div className="flex-grow w-full h-96">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
            <XAxis dataKey="date" stroke="#A0AEC0" />
            <YAxis stroke="#A0AEC0" domain={['dataMin - 10', 'dataMax + 10']} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#2D3748',
                borderColor: '#4A5568',
                color: '#E2E8F0',
              }}
              formatter={(value: number) => `$${value.toFixed(2)}`}
            />
            <Legend wrapperStyle={{ color: '#E2E8F0' }} />
            <Line type="monotone" dataKey="price" name={symbol} stroke={isPositive ? '#48BB78' : '#F56565'} strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default StockChart;
