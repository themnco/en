
import { GoogleGenAI } from "@google/genai";
import { CompanyInfo, GroundingSource } from "../types";

export async function getCompanyInfo(symbol: string): Promise<CompanyInfo> {
  if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
    return {
        summary: "Could not fetch company information because the API key is missing. Please ensure it is configured correctly in the environment.",
        sources: []
    };
  }
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `Provide a concise, up-to-date summary for the company with the stock symbol "${symbol}". Include recent news highlights, a brief overview of its financial performance, and its future outlook. The tone should be neutral and informative, suitable for an investor. Format the output as markdown with headings and bullet points where appropriate.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const summary = response.text;
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    const sources: GroundingSource[] = groundingChunks
      .filter((chunk: any) => chunk.web && chunk.web.uri && chunk.web.title)
      .map((chunk: any) => ({
          web: {
              uri: chunk.web.uri,
              title: chunk.web.title,
          }
      }));

    return { summary, sources };
  } catch (error) {
    console.error("Error fetching company info from Gemini:", error);
    let errorMessage = "An unknown error occurred while fetching data.";
    if (error instanceof Error) {
        errorMessage = error.message;
    }
    return {
        summary: `Failed to retrieve information for ${symbol}. Reason: ${errorMessage}`,
        sources: []
    };
  }
}
