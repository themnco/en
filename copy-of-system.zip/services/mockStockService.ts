
import { ChartDataPoint } from '../types';

export const generateMockStockData = (symbol: string): ChartDataPoint[] => {
  const data: ChartDataPoint[] = [];
  const days = 90;
  // Use a hash of the symbol to seed the random data for some consistency
  let seed = 0;
  for (let i = 0; i < symbol.length; i++) {
    seed += symbol.charCodeAt(i);
  }
  
  let price = (seed % 200) + 50; // Start price between 50 and 250

  const today = new Date();

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    // Simulate some volatility
    const changePercent = 2 * (Math.random() - 0.5) + (Math.sin(i + seed) * 0.5); // Add a sine wave for some pattern
    price *= 1 + changePercent / 100;
    price = Math.max(price, 1); // Don't let price go to zero

    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      price: parseFloat(price.toFixed(2)),
    });
  }
  return data;
};
