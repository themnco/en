
export interface ChartDataPoint {
  date: string;
  price: number;
}

export interface GroundingSource {
  web: {
    uri: string;
    title: string;
  };
}

export interface CompanyInfo {
  summary: string;
  sources: GroundingSource[];
}
